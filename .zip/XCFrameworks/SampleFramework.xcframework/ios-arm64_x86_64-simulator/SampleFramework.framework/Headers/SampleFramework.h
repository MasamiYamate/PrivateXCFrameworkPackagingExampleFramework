//
//  SampleFramework.h
//  SampleFramework
//
//  Created by Masami on 2023/12/10.
//

#import <Foundation/Foundation.h>

//! Project version number for SampleFramework.
FOUNDATION_EXPORT double SampleFrameworkVersionNumber;

//! Project version string for SampleFramework.
FOUNDATION_EXPORT const unsigned char SampleFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SampleFramework/PublicHeader.h>


